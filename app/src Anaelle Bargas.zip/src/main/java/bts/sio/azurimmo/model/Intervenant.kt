package bts.sio.azurimmo.model


data class Intervenant (
    val nom: String
)