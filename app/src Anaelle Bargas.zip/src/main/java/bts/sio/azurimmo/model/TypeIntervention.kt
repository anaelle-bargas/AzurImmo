package bts.sio.azurimmo.model

data class TypeIntervention(
    val libelle:String
)
