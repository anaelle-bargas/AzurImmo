package bts.sio.azurimmo.model

import java.util.Date

data class Associe(
    val nom:String,
    val prenom:String,
    val date_naissance:Date
)
